import { main } from "./ts/classic/classic-editor";
import "./scss/editor-classic.scss";
import "./scss/mistake.scss";

addEventListener("load", () => main());
