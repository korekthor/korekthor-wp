<?php return array('dependencies' => array('jquery', 'react', 'wp-block-editor', 'wp-components', 'wp-data', 'wp-edit-post', 'wp-plugins'), 'version' => '94e339d9548286528d6f');
