<?php return array('dependencies' => array('jquery'), 'version' => 'c25d958171ef1e704477');
