<?php return array('dependencies' => array(), 'version' => '2a123c9cfddad35e489c');
